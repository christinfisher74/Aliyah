# Feminine Strength Co. · Aliyah — Master Format v1

This is the new-format Aliyah client experience built as a reusable platform shell rather than a Frankie-specific app.

## What this build demonstrates
- Data-driven client profile
- Client-specific weekly rhythm
- Configurable daily check-in
- Training with set-level weight/reps logging
- Inline rest/movement timers
- Exercise video links
- Nutrition logging
- Walking/cardio logging
- Progress + wins
- Coach Hub view
- Private-resource placeholder
- Mobile-first/PWA-ready shell
- Supabase-ready schema with Auth + RLS architecture

## Important
The browser app runs in demo mode until you add your existing Supabase public anon/publishable key to `config.js` and move the client records into the schema-backed repository.

Never put a service-role/secret key in `config.js`.

## Supabase setup
1. Open the Supabase SQL Editor for the Feminine Strength Co. project.
2. Run `supabase_schema_v1.sql`.
3. Enable Supabase Auth and create coach/client users.
4. Create a **private** Storage bucket named `client-attachments`.
5. The schema creates a **private** `client-attachments` bucket and adds object-level policies.
6. Use Storage object paths beginning with the client UUID, e.g. `<client_id>/file.pdf`.
7. Put the existing public anon/publishable key in `config.js`.
8. Change `DEMO_MODE` to `false` only after the database is seeded and tested.

## Architecture
Platform → reusable libraries/templates → client programming → client data.

Aliyah's schedule, nutrition settings, baseline measurements and coaching language are client configuration. They are not global rules for Feminine Strength Co.

## Deployment
Upload the contents of this folder to a new GitHub Pages repository or replace a client folder with these files. Do not expose any secret/service-role credential.
