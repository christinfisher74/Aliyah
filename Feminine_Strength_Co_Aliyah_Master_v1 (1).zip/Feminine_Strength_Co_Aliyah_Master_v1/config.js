window.FSC_CONFIG = {
  SUPABASE_URL: 'https://mimaexschnbsdnfcluev.supabase.co',
  // Paste your existing Supabase public anon/publishable key here before deploying.
  // NEVER put a service-role/secret key in this file.
  SUPABASE_PUBLISHABLE_KEY: '',
  DEMO_MODE: true
};
