-- Feminine Strength Co. Master Platform v1
-- Run in Supabase SQL Editor. This is the architecture layer, not a Frankie/Aliyah-specific schema.
-- NEVER put a service-role key in the browser.

create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  role text not null check (role in ('coach','client')),
  first_name text,
  last_name text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.clients (
  id uuid primary key default gen_random_uuid(),
  user_id uuid unique references public.profiles(id) on delete set null,
  coach_id uuid not null references public.profiles(id) on delete restrict,
  display_name text not null,
  status text not null default 'active',
  start_date date,
  profile_data jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.client_settings (
  client_id uuid primary key references public.clients(id) on delete cascade,
  training jsonb not null default '{}'::jsonb,
  nutrition jsonb not null default '{}'::jsonb,
  tracking jsonb not null default '{}'::jsonb,
  checkin jsonb not null default '{}'::jsonb,
  cycle jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.exercises (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  category text,
  equipment text,
  muscle_focus text,
  coaching_cues text,
  video_url text,
  default_sets integer,
  default_reps text,
  default_duration_seconds integer,
  default_rest_seconds integer,
  is_active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.workout_templates (
  id uuid primary key default gen_random_uuid(),
  coach_id uuid not null references public.profiles(id) on delete restrict,
  name text not null,
  focus text,
  description text,
  is_active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.workout_template_exercises (
  id uuid primary key default gen_random_uuid(),
  template_id uuid not null references public.workout_templates(id) on delete cascade,
  exercise_id uuid not null references public.exercises(id) on delete restrict,
  sort_order integer not null default 0,
  sets integer,
  reps text,
  duration_seconds integer,
  rest_seconds integer,
  coaching_cues text,
  progression_rule text
);

create table if not exists public.client_workouts (
  id uuid primary key default gen_random_uuid(),
  client_id uuid not null references public.clients(id) on delete cascade,
  template_id uuid references public.workout_templates(id) on delete set null,
  name text not null,
  training_day text,
  scheduled_date date,
  focus text,
  status text not null default 'assigned',
  session_note text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.client_workout_exercises (
  id uuid primary key default gen_random_uuid(),
  workout_id uuid not null references public.client_workouts(id) on delete cascade,
  exercise_id uuid not null references public.exercises(id) on delete restrict,
  sort_order integer not null default 0,
  sets integer,
  reps text,
  duration_seconds integer,
  rest_seconds integer,
  coaching_cues text,
  progression_rule text
);

create table if not exists public.workout_sets (
  id uuid primary key default gen_random_uuid(),
  client_workout_exercise_id uuid not null references public.client_workout_exercises(id) on delete cascade,
  set_number integer not null,
  prescribed_weight numeric,
  prescribed_reps numeric,
  actual_weight numeric,
  actual_reps numeric,
  duration_seconds integer,
  completed boolean not null default false,
  notes text,
  completed_at timestamptz,
  unique(client_workout_exercise_id,set_number)
);

create table if not exists public.checkin_templates (
  id uuid primary key default gen_random_uuid(),
  coach_id uuid not null references public.profiles(id) on delete restrict,
  name text not null,
  description text,
  created_at timestamptz not null default now()
);

create table if not exists public.checkin_questions (
  id uuid primary key default gen_random_uuid(),
  template_id uuid not null references public.checkin_templates(id) on delete cascade,
  question text not null,
  response_type text not null default 'text',
  options jsonb not null default '[]'::jsonb,
  sort_order integer not null default 0,
  required boolean not null default false
);

create table if not exists public.client_checkins (
  id uuid primary key default gen_random_uuid(),
  client_id uuid not null references public.clients(id) on delete cascade,
  checkin_template_id uuid references public.checkin_templates(id) on delete set null,
  checkin_date date not null,
  responses jsonb not null default '{}'::jsonb,
  coach_response text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique(client_id,checkin_date)
);

create table if not exists public.nutrition_logs (
  id uuid primary key default gen_random_uuid(),
  client_id uuid not null references public.clients(id) on delete cascade,
  log_date date not null,
  meal_name text,
  protein_g numeric,
  calories numeric,
  notes text,
  created_at timestamptz not null default now()
);

create table if not exists public.movement_logs (
  id uuid primary key default gen_random_uuid(),
  client_id uuid not null references public.clients(id) on delete cascade,
  log_date date not null,
  activity_type text not null,
  duration_minutes numeric,
  distance numeric,
  steps integer,
  intensity text,
  notes text,
  created_at timestamptz not null default now()
);

create table if not exists public.progress_entries (
  id uuid primary key default gen_random_uuid(),
  client_id uuid not null references public.clients(id) on delete cascade,
  entry_date date not null,
  weight numeric,
  lean_mass numeric,
  body_fat numeric,
  notes text,
  created_at timestamptz not null default now()
);

create table if not exists public.client_wins (
  id uuid primary key default gen_random_uuid(),
  client_id uuid not null references public.clients(id) on delete cascade,
  win_date date not null default current_date,
  text text not null,
  created_at timestamptz not null default now()
);

create table if not exists public.coach_notes (
  id uuid primary key default gen_random_uuid(),
  client_id uuid not null references public.clients(id) on delete cascade,
  coach_id uuid not null references public.profiles(id) on delete restrict,
  note_date date not null default current_date,
  note text not null,
  created_at timestamptz not null default now()
);

create table if not exists public.client_attachments (
  id uuid primary key default gen_random_uuid(),
  client_id uuid not null references public.clients(id) on delete cascade,
  uploaded_by uuid not null references public.profiles(id) on delete restrict,
  file_name text not null,
  storage_path text not null,
  file_type text,
  description text,
  created_at timestamptz not null default now()
);

create index if not exists idx_clients_coach on public.clients(coach_id);
create index if not exists idx_workouts_client_date on public.client_workouts(client_id,scheduled_date);
create index if not exists idx_checkins_client_date on public.client_checkins(client_id,checkin_date);
create index if not exists idx_nutrition_client_date on public.nutrition_logs(client_id,log_date);
create index if not exists idx_movement_client_date on public.movement_logs(client_id,log_date);
create index if not exists idx_notes_client_date on public.coach_notes(client_id,note_date);

alter table public.profiles enable row level security;
alter table public.clients enable row level security;
alter table public.client_settings enable row level security;
alter table public.exercises enable row level security;
alter table public.workout_templates enable row level security;
alter table public.workout_template_exercises enable row level security;
alter table public.client_workouts enable row level security;
alter table public.client_workout_exercises enable row level security;
alter table public.workout_sets enable row level security;
alter table public.checkin_templates enable row level security;
alter table public.checkin_questions enable row level security;
alter table public.client_checkins enable row level security;
alter table public.nutrition_logs enable row level security;
alter table public.movement_logs enable row level security;
alter table public.progress_entries enable row level security;
alter table public.client_wins enable row level security;
alter table public.coach_notes enable row level security;
alter table public.client_attachments enable row level security;

create or replace function public.is_coach() returns boolean language sql stable security definer set search_path=public as $$
  select exists(select 1 from public.profiles p where p.id=auth.uid() and p.role='coach');
$$;

create or replace function public.client_belongs_to_user(p_client_id uuid) returns boolean language sql stable security definer set search_path=public as $$
  select exists(select 1 from public.clients c where c.id=p_client_id and c.user_id=auth.uid());
$$;

create or replace function public.client_belongs_to_coach(p_client_id uuid) returns boolean language sql stable security definer set search_path=public as $$
  select exists(select 1 from public.clients c where c.id=p_client_id and c.coach_id=auth.uid());
$$;

-- Profiles: users can read/update their own profile; coaches may read profiles needed for their clients.
create policy profiles_self on public.profiles for select using (id=auth.uid() or public.is_coach());
create policy profiles_update_self on public.profiles for update using (id=auth.uid()) with check (id=auth.uid());

-- Clients: client sees only self; coach sees clients assigned to that coach.
create policy clients_select on public.clients for select using (user_id=auth.uid() or coach_id=auth.uid());
create policy clients_insert_coach on public.clients for insert with check (public.is_coach() and coach_id=auth.uid());
create policy clients_update_coach on public.clients for update using (coach_id=auth.uid()) with check (coach_id=auth.uid());

create policy client_settings_access on public.client_settings for all using (public.client_belongs_to_user(client_id) or public.client_belongs_to_coach(client_id)) with check (public.client_belongs_to_user(client_id) or public.client_belongs_to_coach(client_id));

-- Exercise library is readable by authenticated users; only coaches manage it.
create policy exercises_read_auth on public.exercises for select using (auth.uid() is not null);
create policy exercises_manage_coach on public.exercises for all using (public.is_coach()) with check (public.is_coach());

create policy templates_coach on public.workout_templates for all using (coach_id=auth.uid()) with check (coach_id=auth.uid());
create policy template_exercises_coach on public.workout_template_exercises for all using (exists(select 1 from public.workout_templates t where t.id=template_id and t.coach_id=auth.uid())) with check (exists(select 1 from public.workout_templates t where t.id=template_id and t.coach_id=auth.uid()));

create policy client_workouts_access on public.client_workouts for all using (public.client_belongs_to_user(client_id) or public.client_belongs_to_coach(client_id)) with check (public.client_belongs_to_user(client_id) or public.client_belongs_to_coach(client_id));
create policy client_workout_exercises_access on public.client_workout_exercises for all using (exists(select 1 from public.client_workouts w where w.id=workout_id and (public.client_belongs_to_user(w.client_id) or public.client_belongs_to_coach(w.client_id)))) with check (exists(select 1 from public.client_workouts w where w.id=workout_id and (public.client_belongs_to_user(w.client_id) or public.client_belongs_to_coach(w.client_id))));
create policy workout_sets_access on public.workout_sets for all using (exists(select 1 from public.client_workout_exercises e join public.client_workouts w on w.id=e.workout_id where e.id=client_workout_exercise_id and (public.client_belongs_to_user(w.client_id) or public.client_belongs_to_coach(w.client_id)))) with check (exists(select 1 from public.client_workout_exercises e join public.client_workouts w on w.id=e.workout_id where e.id=client_workout_exercise_id and (public.client_belongs_to_user(w.client_id) or public.client_belongs_to_coach(w.client_id))));

create policy checkin_templates_coach on public.checkin_templates for all using (coach_id=auth.uid()) with check (coach_id=auth.uid());
create policy checkin_questions_coach on public.checkin_questions for all using (exists(select 1 from public.checkin_templates t where t.id=template_id and t.coach_id=auth.uid())) with check (exists(select 1 from public.checkin_templates t where t.id=template_id and t.coach_id=auth.uid()));
create policy client_checkins_access on public.client_checkins for all using (public.client_belongs_to_user(client_id) or public.client_belongs_to_coach(client_id)) with check (public.client_belongs_to_user(client_id) or public.client_belongs_to_coach(client_id));

create policy nutrition_access on public.nutrition_logs for all using (public.client_belongs_to_user(client_id) or public.client_belongs_to_coach(client_id)) with check (public.client_belongs_to_user(client_id) or public.client_belongs_to_coach(client_id));
create policy movement_access on public.movement_logs for all using (public.client_belongs_to_user(client_id) or public.client_belongs_to_coach(client_id)) with check (public.client_belongs_to_user(client_id) or public.client_belongs_to_coach(client_id));
create policy progress_access on public.progress_entries for all using (public.client_belongs_to_user(client_id) or public.client_belongs_to_coach(client_id)) with check (public.client_belongs_to_user(client_id) or public.client_belongs_to_coach(client_id));
create policy wins_access on public.client_wins for all using (public.client_belongs_to_user(client_id) or public.client_belongs_to_coach(client_id)) with check (public.client_belongs_to_user(client_id) or public.client_belongs_to_coach(client_id));
create policy notes_access on public.coach_notes for all using (public.client_belongs_to_user(client_id) or public.client_belongs_to_coach(client_id)) with check (public.is_coach() and coach_id=auth.uid() and public.client_belongs_to_coach(client_id));
create policy attachments_access on public.client_attachments for all using (public.client_belongs_to_user(client_id) or public.client_belongs_to_coach(client_id)) with check (public.client_belongs_to_user(client_id) or public.client_belongs_to_coach(client_id));

-- Private bucket. Create the bucket in Storage UI or with the Storage API as a private bucket named client-attachments.
-- Storage object policies should use the client UUID as the first folder segment: <client_id>/<filename>.

-- Private attachment bucket and object-level access.
insert into storage.buckets (id, name, public)
values ('client-attachments', 'client-attachments', false)
on conflict (id) do nothing;

create policy client_attachment_read on storage.objects
for select using (
  bucket_id = 'client-attachments'
  and exists (
    select 1 from public.clients c
    where c.id::text = split_part(name,'/',1)
      and (c.user_id = auth.uid() or c.coach_id = auth.uid())
  )
);

create policy client_attachment_upload on storage.objects
for insert with check (
  bucket_id = 'client-attachments'
  and public.is_coach()
  and exists (
    select 1 from public.clients c
    where c.id::text = split_part(name,'/',1)
      and c.coach_id = auth.uid()
  )
);

create policy client_attachment_update on storage.objects
for update using (
  bucket_id = 'client-attachments'
  and public.is_coach()
  and exists (
    select 1 from public.clients c
    where c.id::text = split_part(name,'/',1)
      and c.coach_id = auth.uid()
  )
) with check (
  bucket_id = 'client-attachments'
  and public.is_coach()
  and exists (
    select 1 from public.clients c
    where c.id::text = split_part(name,'/',1)
      and c.coach_id = auth.uid()
  )
);

create policy client_attachment_delete on storage.objects
for delete using (
  bucket_id = 'client-attachments'
  and public.is_coach()
  and exists (
    select 1 from public.clients c
    where c.id::text = split_part(name,'/',1)
      and c.coach_id = auth.uid()
  )
);
